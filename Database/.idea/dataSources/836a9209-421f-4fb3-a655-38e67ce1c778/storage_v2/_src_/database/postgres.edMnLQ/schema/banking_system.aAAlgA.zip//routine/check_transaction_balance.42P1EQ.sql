create function check_transaction_balance() returns trigger
    language plpgsql
as
$$
DECLARE
    sender_balance DECIMAL(12,2);
BEGIN
    SELECT balance INTO sender_balance
    FROM account
    WHERE account_id = NEW.senderAccount_id;

    IF NEW.amount > sender_balance THEN
        RAISE EXCEPTION 'Transaction amount exceeds recipient account balance';
    END IF;

    RETURN NEW;
END;
$$;

alter function check_transaction_balance() owner to postgres;

