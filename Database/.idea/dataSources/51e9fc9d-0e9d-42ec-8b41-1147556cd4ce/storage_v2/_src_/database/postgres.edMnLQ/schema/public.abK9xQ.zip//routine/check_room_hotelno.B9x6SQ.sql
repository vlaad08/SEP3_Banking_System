create function check_room_hotelno() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.hotelno != OLD.hotelno THEN
        RAISE EXCEPTION 'Cannot change hotelNo of room in hotel EXCEPTION!!!';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_room_hotelno() owner to postgres;

