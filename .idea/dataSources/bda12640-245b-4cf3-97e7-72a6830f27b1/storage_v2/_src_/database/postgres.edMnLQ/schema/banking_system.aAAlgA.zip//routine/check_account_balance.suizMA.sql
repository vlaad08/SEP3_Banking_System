create function check_account_balance() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.balance < 0 THEN
        RAISE EXCEPTION 'Account balance cannot be negative';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_account_balance() owner to postgres;

